# 📡 API Documentation - Healthcare CRM

## Overview

This document describes the REST API endpoints for the Healthcare CRM backend when deployed with Supabase Edge Functions and PostgreSQL.

**Base URL**: `https://your-project.supabase.co/functions/v1`

**Authentication**: All endpoints require JWT token in Authorization header
```
Authorization: Bearer <jwt_token>
```

---

## Endpoints

### 1. Create Interaction

**POST** `/api/interaction`

Create a new HCP interaction record.

#### Request Body

```json
{
  "hcpName": "Dr. Sharma",
  "hospitalName": "Apollo Hospital",
  "interactionType": "in-person",
  "date": "2026-04-17",
  "time": "14:30",
  "notes": "Discussed new cardiology product line. Very receptive to clinical trial participation.",
  "productsDiscussed": ["CardioMax", "HeartGuard Plus"],
  "followUpRequired": true,
  "followUpDate": "2026-05-01",
  "followUpNotes": "Share phase 3 trial results",
  "meetingDuration": "45 minutes",
  "interactionOutcome": "Positive",
  "keyDiscussionPoints": "Clinical trial participation, product efficacy data"
}
```

#### Response

**Success (201 Created)**
```json
{
  "success": true,
  "data": {
    "id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    "userId": "user123",
    "hcpName": "Dr. Sharma",
    "hospitalName": "Apollo Hospital",
    "interactionType": "in-person",
    "date": "2026-04-17",
    "time": "14:30",
    "notes": "Discussed new cardiology product line...",
    "productsDiscussed": ["CardioMax", "HeartGuard Plus"],
    "followUpRequired": true,
    "followUpDate": "2026-05-01",
    "followUpNotes": "Share phase 3 trial results",
    "meetingDuration": "45 minutes",
    "interactionOutcome": "Positive",
    "keyDiscussionPoints": "Clinical trial participation...",
    "createdAt": "2026-04-17T14:30:00Z",
    "updatedAt": "2026-04-17T14:30:00Z"
  },
  "message": "Interaction logged successfully"
}
```

**Error (400 Bad Request)**
```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Missing required fields",
    "fields": ["hcpName", "hospitalName"]
  }
}
```

---

### 2. Get Interactions

**GET** `/api/interactions`

Retrieve all interactions for the authenticated user.

#### Query Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| page | integer | 1 | Page number for pagination |
| limit | integer | 20 | Items per page (max 100) |
| sortBy | string | "date" | Sort field (date, hcpName, hospitalName) |
| order | string | "desc" | Sort order (asc, desc) |
| startDate | string | - | Filter by start date (ISO 8601) |
| endDate | string | - | Filter by end date (ISO 8601) |
| hcpName | string | - | Filter by HCP name (partial match) |
| hospitalName | string | - | Filter by hospital (partial match) |
| interactionType | string | - | Filter by type (in-person, virtual, phone, email) |
| followUpRequired | boolean | - | Filter by follow-up status |

#### Example Request

```
GET /api/interactions?page=1&limit=10&sortBy=date&order=desc&startDate=2026-04-01
```

#### Response

**Success (200 OK)**
```json
{
  "success": true,
  "data": [
    {
      "id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
      "hcpName": "Dr. Sharma",
      "hospitalName": "Apollo Hospital",
      "interactionType": "in-person",
      "date": "2026-04-17",
      "time": "14:30",
      "notes": "Discussed new cardiology product line...",
      "productsDiscussed": ["CardioMax", "HeartGuard Plus"],
      "followUpRequired": true,
      "followUpDate": "2026-05-01",
      "interactionOutcome": "Positive",
      "createdAt": "2026-04-17T14:30:00Z"
    },
    {
      "id": "b2c3d4e5-f6g7-8901-bcde-fg2345678901",
      "hcpName": "Dr. Kumar",
      "hospitalName": "Fortis Healthcare",
      "interactionType": "virtual",
      "date": "2026-04-15",
      "notes": "Product demo session...",
      "productsDiscussed": ["NeuroVital"],
      "followUpRequired": false,
      "interactionOutcome": "Neutral",
      "createdAt": "2026-04-15T10:00:00Z"
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 47,
    "totalPages": 5,
    "hasNext": true,
    "hasPrev": false
  }
}
```

---

### 3. Get Single Interaction

**GET** `/api/interaction/:id`

Retrieve a specific interaction by ID.

#### Path Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| id | UUID | Interaction ID |

#### Response

**Success (200 OK)**
```json
{
  "success": true,
  "data": {
    "id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    "hcpName": "Dr. Sharma",
    "hospitalName": "Apollo Hospital",
    "interactionType": "in-person",
    "date": "2026-04-17",
    "time": "14:30",
    "notes": "Discussed new cardiology product line...",
    "productsDiscussed": ["CardioMax", "HeartGuard Plus"],
    "followUpRequired": true,
    "followUpDate": "2026-05-01",
    "followUpNotes": "Share phase 3 trial results",
    "meetingDuration": "45 minutes",
    "interactionOutcome": "Positive",
    "keyDiscussionPoints": "Clinical trial participation...",
    "createdAt": "2026-04-17T14:30:00Z",
    "updatedAt": "2026-04-17T14:30:00Z"
  }
}
```

**Error (404 Not Found)**
```json
{
  "success": false,
  "error": {
    "code": "NOT_FOUND",
    "message": "Interaction not found"
  }
}
```

---

### 4. Update Interaction

**PUT** `/api/interaction/:id`

Update an existing interaction.

#### Path Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| id | UUID | Interaction ID |

#### Request Body

Send only the fields you want to update:

```json
{
  "notes": "Updated notes with additional insights",
  "interactionOutcome": "Positive",
  "followUpDate": "2026-05-15"
}
```

#### Response

**Success (200 OK)**
```json
{
  "success": true,
  "data": {
    "id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    "hcpName": "Dr. Sharma",
    "notes": "Updated notes with additional insights",
    "interactionOutcome": "Positive",
    "followUpDate": "2026-05-15",
    "updatedAt": "2026-04-17T15:45:00Z"
  },
  "message": "Interaction updated successfully"
}
```

---

### 5. Delete Interaction

**DELETE** `/api/interaction/:id`

Delete an interaction permanently.

#### Path Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| id | UUID | Interaction ID |

#### Response

**Success (200 OK)**
```json
{
  "success": true,
  "message": "Interaction deleted successfully"
}
```

**Error (403 Forbidden)**
```json
{
  "success": false,
  "error": {
    "code": "FORBIDDEN",
    "message": "You don't have permission to delete this interaction"
  }
}
```

---

### 6. Chat with AI Agent

**POST** `/api/chat`

Send a message to the AI agent for conversational interaction logging.

#### Request Body

```json
{
  "message": "I met Dr. Sharma from Apollo Hospital today",
  "context": {
    "currentInteraction": {
      "hcpName": "",
      "hospitalName": "",
      "interactionType": "",
      "date": "2026-04-17",
      "time": "14:30",
      "notes": "",
      "productsDiscussed": [],
      "followUpRequired": false
    },
    "conversationHistory": [
      {
        "role": "assistant",
        "content": "Who did you meet today?"
      }
    ]
  }
}
```

#### Response

**Success (200 OK)**
```json
{
  "success": true,
  "data": {
    "message": "Great! I've noted that you met with Dr. Sharma at Apollo Hospital.\n\nWhat type of interaction was this? (in-person, virtual, phone call, etc.)",
    "extractedData": {
      "hcpName": "Dr. Sharma",
      "hospitalName": "Apollo Hospital"
    },
    "nextQuestion": "What type of interaction was this?",
    "confidence": {
      "hcpName": 0.95,
      "hospitalName": 0.92
    },
    "conversationComplete": false
  }
}
```

---

### 7. Get Analytics

**GET** `/api/analytics`

Retrieve interaction analytics and insights.

#### Query Parameters

| Parameter | Type | Description |
|-----------|------|---------|
| startDate | string | Start date for analytics period |
| endDate | string | End date for analytics period |
| groupBy | string | Group by: day, week, month |

#### Response

**Success (200 OK)**
```json
{
  "success": true,
  "data": {
    "totalInteractions": 47,
    "byType": {
      "in-person": 28,
      "virtual": 12,
      "phone": 5,
      "email": 2
    },
    "byOutcome": {
      "Positive": 32,
      "Neutral": 10,
      "Needs Follow-up": 5
    },
    "topHCPs": [
      { "name": "Dr. Sharma", "count": 5 },
      { "name": "Dr. Kumar", "count": 4 }
    ],
    "topHospitals": [
      { "name": "Apollo Hospital", "count": 12 },
      { "name": "Fortis Healthcare", "count": 8 }
    ],
    "topProducts": [
      { "name": "CardioMax", "count": 15 },
      { "name": "NeuroVital", "count": 10 }
    ],
    "followUpRate": 0.34,
    "averageDuration": "38 minutes",
    "interactionsByDate": [
      { "date": "2026-04-15", "count": 3 },
      { "date": "2026-04-16", "count": 5 },
      { "date": "2026-04-17", "count": 2 }
    ]
  }
}
```

---

## Error Codes

| Code | HTTP Status | Description |
|------|-------------|-------------|
| VALIDATION_ERROR | 400 | Invalid request data |
| UNAUTHORIZED | 401 | Missing or invalid authentication |
| FORBIDDEN | 403 | Insufficient permissions |
| NOT_FOUND | 404 | Resource not found |
| RATE_LIMIT_EXCEEDED | 429 | Too many requests |
| INTERNAL_ERROR | 500 | Server error |
| AI_SERVICE_ERROR | 503 | AI service unavailable |

---

## Rate Limiting

- **Authenticated users**: 100 requests per minute
- **Chat endpoint**: 20 requests per minute (AI processing is expensive)
- **Bulk operations**: 10 requests per minute

Rate limit headers included in responses:
```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1713369600
```

---

## Authentication

### Get JWT Token

**POST** `/auth/login`

```json
{
  "email": "user@example.com",
  "password": "securePassword123"
}
```

**Response**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "expires_in": 3600,
  "user": {
    "id": "user123",
    "email": "user@example.com",
    "role": "field_rep"
  }
}
```

### Refresh Token

**POST** `/auth/refresh`

```json
{
  "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

---

## Webhook Events

Configure webhooks to receive real-time notifications:

### Event Types

- `interaction.created` - New interaction logged
- `interaction.updated` - Interaction modified
- `interaction.deleted` - Interaction removed
- `followup.due` - Follow-up date approaching (24h notice)

### Webhook Payload

```json
{
  "event": "interaction.created",
  "timestamp": "2026-04-17T14:30:00Z",
  "data": {
    "id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    "userId": "user123",
    "hcpName": "Dr. Sharma",
    "hospitalName": "Apollo Hospital"
  }
}
```

---

## SDKs

### JavaScript/TypeScript

```bash
npm install @healthcare-crm/sdk
```

```typescript
import { HealthcareCRM } from '@healthcare-crm/sdk';

const crm = new HealthcareCRM({
  apiKey: 'your_api_key',
  supabaseUrl: 'https://your-project.supabase.co'
});

// Create interaction
const interaction = await crm.interactions.create({
  hcpName: 'Dr. Sharma',
  hospitalName: 'Apollo Hospital',
  interactionType: 'in-person',
  date: '2026-04-17'
});

// Chat with AI
const response = await crm.chat.send('I met Dr. Sharma today');
console.log(response.extractedData);
```

### Python

```bash
pip install healthcare-crm-sdk
```

```python
from healthcare_crm import Client

client = Client(
    api_key='your_api_key',
    supabase_url='https://your-project.supabase.co'
)

# Create interaction
interaction = client.interactions.create(
    hcp_name='Dr. Sharma',
    hospital_name='Apollo Hospital',
    interaction_type='in-person',
    date='2026-04-17'
)

# Chat with AI
response = client.chat.send('I met Dr. Sharma today')
print(response.extracted_data)
```

---

## Testing

### Postman Collection

Import our Postman collection for easy API testing:
```
https://healthcare-crm.api/postman-collection.json
```

### cURL Examples

**Create Interaction**
```bash
curl -X POST https://your-project.supabase.co/functions/v1/api/interaction \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "hcpName": "Dr. Sharma",
    "hospitalName": "Apollo Hospital",
    "interactionType": "in-person",
    "date": "2026-04-17"
  }'
```

**Get Interactions**
```bash
curl -X GET "https://your-project.supabase.co/functions/v1/api/interactions?page=1&limit=10" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

**Chat with AI**
```bash
curl -X POST https://your-project.supabase.co/functions/v1/api/chat \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "message": "I met Dr. Sharma from Apollo today",
    "context": {
      "currentInteraction": {}
    }
  }'
```

---

## Changelog

### v1.0.0 (2026-04-17)
- Initial API release
- CRUD operations for interactions
- AI chat endpoint
- Analytics endpoint
- Authentication via Supabase Auth

---

For support, contact: api-support@healthcare-crm.com

# 🎨 Design Specifications - Pixel Perfect Guide

## 📐 Exact Measurements

### Layout Grid

```
Total Width: 1400px max-width
Container Padding: 24px (px-6)

LEFT PANEL (Form):
- Width: 70% (7/10 grid columns)
- Padding: 24px
- Background: #ffffff
- Border: 1px solid #d1d5db
- Border Radius: 8px

RIGHT PANEL (Chat):
- Width: 30% (3/10 grid columns)
- Padding: 16px
- Background: #ffffff
- Border: 1px solid #d1d5db
- Border Radius: 8px
- Position: sticky
- Top: 96px (for navbar clearance)

Gap Between Panels: 24px
```

---

## 🎯 Component Spacing

### Navbar

```css
Height: 64px
Padding: 0 24px
Background: #ffffff
Border Bottom: 1px solid #e5e7eb
Position: sticky
Top: 0
Z-index: 50

Logo Section:
- Icon: 36px × 36px
- Border Radius: 8px
- Gradient: from-blue-600 to-blue-700

Navigation Buttons:
- Padding: 8px 16px
- Font Size: 14px
- Border Radius: 6px
```

### Page Header

```css
Background: #ffffff
Border Bottom: 1px solid #e5e7eb
Padding: 24px

Title:
- Font Size: 24px
- Font Weight: 700
- Color: #111827

Subtitle:
- Font Size: 14px
- Color: #6b7280
- Margin Top: 4px

Stats Box:
- Background: #f9fafb
- Padding: 8px 16px
- Border: 1px solid #e5e7eb
- Border Radius: 8px
```

### Form Card

```css
Header:
- Background: #f9fafb
- Padding: 16px 24px
- Border Bottom: 1px solid #e5e7eb
- Font Size: 14px
- Font Weight: 600

Body:
- Padding: 24px
- Space Between Fields: 20px (space-y-5)
```

### Form Fields

```css
Label:
- Font Size: 14px
- Font Weight: 500
- Color: #374151
- Margin Bottom: 6px

Input/Textarea:
- Padding: 8px 12px
- Font Size: 14px
- Border: 1px solid #d1d5db
- Border Radius: 6px
- Color: #111827

Placeholder:
- Color: #9ca3af

Focus State:
- Ring: 2px solid #3b82f6
- Border: transparent

Disabled State:
- Background: #f9fafb
- Color: #9ca3af
- Cursor: not-allowed
```

### Date + Time Row

```css
Grid: 2 columns
Gap: 16px

Each Input:
- Width: 50% (auto from grid)
- Same styling as text inputs
```

### Materials/Samples Section

```css
Container:
- Background: #f9fafb
- Border: 1px solid #e5e7eb
- Padding: 16px
- Border Radius: 6px

Sub-section Spacing: 16px

Button (Search/Add):
- Padding: 6px 12px
- Font Size: 12px
- Background: #ffffff
- Border: 1px solid #d1d5db
- Border Radius: 6px
```

### Sentiment Radio Buttons

```css
Container:
- Display: flex
- Gap: 24px

Each Option:
- Radio Size: 16px
- Label Font Size: 14px
- Label Font Weight: 500
- Gap Between Radio and Label: 8px

Colors:
- Positive: #047857 (green-700)
- Neutral: #374151 (gray-700)
- Negative: #b91c1c (red-700)
```

### AI Suggested Actions Box

```css
Container:
- Background: linear-gradient(to bottom right, #eff6ff, #eef2ff)
- Border: 1px solid #bfdbfe
- Padding: 16px
- Border Radius: 6px

AI Badge:
- Size: 24px × 24px
- Background: #2563eb
- Color: #ffffff
- Border Radius: 9999px (full circle)
- Font Size: 12px
- Font Weight: 700

Checkboxes:
- Size: 16px
- Color: #2563eb
- Gap from label: 10px
- Label Font Size: 12px
- Label Color: #1e3a8a (blue-900)
```

### Submit Button

```css
Width: 100%
Padding: 12px 16px
Background: #2563eb
Color: #ffffff
Border Radius: 6px
Font Size: 14px
Font Weight: 600
Shadow: 0 1px 2px rgba(0, 0, 0, 0.05)

Hover:
- Background: #1d4ed8

Disabled:
- Background: #d1d5db
- Cursor: not-allowed
```

---

## 💬 Chat Panel Specifications

### Header

```css
Background: linear-gradient(to right, #eff6ff, #eef2ff)
Padding: 14px 16px
Border Bottom: 1px solid #e5e7eb

Bot Icon Container:
- Size: 32px × 32px
- Background: linear-gradient(to bottom right, #2563eb, #4f46e5)
- Border Radius: 8px
- Icon Size: 20px
- Icon Color: #ffffff

Title:
- Font Size: 14px
- Font Weight: 600
- Color: #111827

Subtitle:
- Font Size: 12px
- Color: #6b7280
```

### Messages Area

```css
Padding: 16px
Space Between Messages: 12px
Max Height: calc(100vh - 280px)
Overflow: auto

AI Message:
- Background: #eff6ff
- Border: 1px solid #bfdbfe
- Padding: 10px 12px
- Border Radius: 8px
- Font Size: 12px
- Line Height: 1.5
- Color: #374151

Bot Icon in Message:
- Size: 20px × 20px
- Background: #2563eb
- Border Radius: 9999px
- Icon Size: 12px

User Message:
- Background: #f3f4f6
- Border: 1px solid #e5e7eb
- Padding: 10px 12px
- Border Radius: 8px
- Margin Left: 24px
- Font Size: 12px
- Color: #374151

Auto-filled Badge:
- Border Top: 1px solid #bfdbfe
- Padding Top: 8px
- Margin Top: 8px
- Font Size: 12px
- Color: #1d4ed8
- Font Weight: 500
```

### Input Area

```css
Background: #f9fafb
Padding: 16px
Border Top: 1px solid #e5e7eb

Textarea:
- Padding: 10px 12px
- Border: 1px solid #d1d5db
- Border Radius: 6px
- Font Size: 14px
- Rows: 3
- Background: #ffffff

Log Button:
- Width: 100%
- Padding: 10px 16px
- Background: #1f2937
- Color: #ffffff
- Border Radius: 6px
- Font Size: 14px
- Font Weight: 600
- Margin Top: 12px

Hover:
- Background: #111827

Helper Text:
- Font Size: 12px
- Color: #6b7280
- Text Align: center
- Margin Top: 12px
- Line Height: 1.5
```

---

## 🌈 Color System

### Primary Palette

```css
/* Blue (Primary) */
--blue-50: #eff6ff;
--blue-100: #dbeafe;
--blue-500: #3b82f6;
--blue-600: #2563eb;
--blue-700: #1d4ed8;
--blue-900: #1e3a8a;

/* Indigo (Accent) */
--indigo-50: #eef2ff;
--indigo-600: #4f46e5;

/* Gray (Neutral) */
--gray-50: #f9fafb;
--gray-100: #f3f4f6;
--gray-200: #e5e7eb;
--gray-300: #d1d5db;
--gray-400: #9ca3af;
--gray-600: #6b7280;
--gray-700: #374151;
--gray-800: #1f2937;
--gray-900: #111827;

/* Semantic Colors */
--green-500: #10b981;  /* Success */
--green-700: #047857;  /* Positive sentiment */
--red-500: #ef4444;    /* Error */
--red-700: #b91c1c;    /* Negative sentiment */
--yellow-500: #f59e0b; /* Warning */
```

---

## 📱 Responsive Breakpoints

```css
/* Mobile First Approach */

/* Extra Small: 0 - 639px */
@media (max-width: 639px) {
  - Single column layout
  - Stack form and chat vertically
  - Reduce padding: 16px
  - Hide stats in header
  - Font sizes: 90%
}

/* Small: 640px - 767px */
@media (min-width: 640px) {
  - Still single column
  - Increase padding: 20px
  - Show abbreviated stats
}

/* Medium: 768px - 1023px */
@media (min-width: 768px) {
  - Navbar shows all items
  - Side-by-side possible but stacked preferred
}

/* Large: 1024px - 1279px */
@media (min-width: 1024px) {
  - 70-30 layout activates
  - Sticky chat panel
  - Full stats display
}

/* Extra Large: 1280px+ */
@media (min-width: 1280px) {
  - Max width container: 1400px
  - Optimal spacing
  - All features visible
}
```

---

## ✨ Animations & Transitions

### Hover Effects

```css
Button Hover:
- Transition: background-color 200ms ease
- Scale: none (avoid layout shift)

Input Focus:
- Transition: all 200ms ease
- Ring appears smoothly

Link Hover:
- Transition: color 150ms ease
```

### Page Transitions

```css
Message Fade In:
- Animation: fade-in 300ms ease
- Transform: slide-in-from-bottom-2

Typing Indicator:
- Animation: bounce (Tailwind default)
- Staggered delays: 0ms, 150ms, 300ms

AI Badge Pulse:
- Animation: pulse 2s infinite (when processing)
```

### Loading States

```css
Button Loading:
- Disabled state
- Spinner icon replaces text
- Opacity: 0.7

Form Submitting:
- Overlay with spinner
- Blur background slightly
```

---

## 🎯 Accessibility

### Focus States

```css
All Interactive Elements:
- Focus ring: 2px solid #3b82f6
- Offset: 2px
- Visible always (no outline: none)

Keyboard Navigation:
- Tab order: logical flow
- Skip links provided
- Focus visible on all controls
```

### Color Contrast

```css
Text on White:
- Minimum contrast: 4.5:1 (WCAG AA)
- Body text: #374151 (gray-700)
- Headings: #111827 (gray-900)

Text on Blue:
- White text: #ffffff
- Contrast: 7:1+ (WCAG AAA)

Disabled States:
- Clear visual indicator
- Not relying on color alone
```

### ARIA Labels

```tsx
<button aria-label="Save interaction">
  <CheckCircle2 /> Save
</button>

<input aria-required="true" />

<div role="alert" aria-live="polite">
  Interaction saved successfully
</div>
```

---

## 📊 Grid System

### Form Layout

```css
Container: max-w-[1400px]
Grid: grid-cols-1 lg:grid-cols-10
Gap: 24px

Form Column: lg:col-span-7 (70%)
Chat Column: lg:col-span-3 (30%)
```

### Inline Fields

```css
Date + Time: grid-cols-2 gap-4
Materials + Samples: nested grids
```

---

## 🔤 Typography Scale

```css
/* Font Family */
font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;

/* Font Sizes */
text-xs: 12px;      /* Helper text, badges */
text-sm: 14px;      /* Body, inputs, labels */
text-base: 16px;    /* Default */
text-lg: 18px;      /* Subheadings */
text-xl: 20px;      /* Section titles */
text-2xl: 24px;     /* Page titles */

/* Font Weights */
font-normal: 400;   /* Body text */
font-medium: 500;   /* Labels, emphasized text */
font-semibold: 600; /* Buttons, headers */
font-bold: 700;     /* Main headings */

/* Line Heights */
leading-none: 1;
leading-tight: 1.25;
leading-normal: 1.5;  /* Default for body */
leading-relaxed: 1.625;
```

---

## 🎨 Shadow System

```css
/* Elevation Levels */
shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);     /* Cards */
shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1);         /* Dropdowns */
shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1);   /* Modals */
shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1); /* Popovers */

/* Focus Shadow */
ring-2 ring-blue-500: Consistent across all inputs
```

---

This pixel-perfect specification ensures consistent, professional design across all components.

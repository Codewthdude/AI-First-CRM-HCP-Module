# 🏗️ Healthcare CRM - System Architecture

## Table of Contents
1. [High-Level Overview](#high-level-overview)
2. [Frontend Architecture](#frontend-architecture)
3. [State Management](#state-management)
4. [AI Agent Design](#ai-agent-design)
5. [Data Flow](#data-flow)
6. [Backend Architecture (Production)](#backend-architecture-production)
7. [Security Architecture](#security-architecture)

---

## High-Level Overview

```
┌─────────────────────────────────────────────────────────────┐
│                      USER INTERFACE                         │
│  ┌──────────────┐              ┌──────────────┐            │
│  │   Chat View  │  ←→ Toggle → │  Form View   │            │
│  └──────────────┘              └──────────────┘            │
│         ↓                              ↓                    │
│  ┌─────────────────────────────────────────────┐           │
│  │          Redux Store (State)                │           │
│  │  ┌────────────┐      ┌──────────────┐      │           │
│  │  │ Chat Slice │      │  Form Slice  │      │           │
│  │  └────────────┘      └──────────────┘      │           │
│  └─────────────────────────────────────────────┘           │
│         ↓                              ↓                    │
│  ┌─────────────────────────────────────────────┐           │
│  │          AI Agent Service                   │           │
│  │  (Entity Extraction & NLP Processing)       │           │
│  └─────────────────────────────────────────────┘           │
└─────────────────────────────────────────────────────────────┘
                           ↓
        ┌──────────────────────────────────────┐
        │  Backend (Supabase + Groq API)       │
        │  ┌────────────┐  ┌───────────────┐   │
        │  │ Edge Funcs │  │  PostgreSQL   │   │
        │  │ (LangGraph)│  │   Database    │   │
        │  └────────────┘  └───────────────┘   │
        └──────────────────────────────────────┘
```

---

## Frontend Architecture

### Component Hierarchy

```
App.tsx (Redux Provider)
  └── MainInterface.tsx (Layout & Toggle Logic)
      ├── ChatView.tsx
      │   ├── Message Components
      │   ├── Input Field
      │   └── Quick Actions
      ├── FormView.tsx
      │   ├── Input Fields
      │   ├── Validation
      │   └── Submit Handler
      ├── InteractionHistory.tsx
      │   └── Interaction Cards
      └── Live Status Panel
          ├── Progress Bar
          └── Field Checklist
```

### Component Responsibilities

#### 1. **MainInterface.tsx**
- **Purpose**: Main layout and view orchestration
- **State**: View toggle (chat/form), history visibility
- **Features**:
  - Toggle between chat and form
  - Display history
  - Live progress tracking
  - Responsive layout

#### 2. **ChatView.tsx**
- **Purpose**: Conversational AI interface
- **Features**:
  - Message rendering (user/assistant)
  - Auto-scroll to latest
  - Typing indicator
  - Quick action buttons
  - Real-time entity extraction display
- **Integration**: Calls AI agent, dispatches to Redux

#### 3. **FormView.tsx**
- **Purpose**: Traditional form interface
- **Features**:
  - All interaction fields
  - Real-time validation
  - Field grouping
  - Submit/reset handlers
  - Conditional fields (follow-up)
- **Integration**: Reads from and writes to Redux

#### 4. **InteractionHistory.tsx**
- **Purpose**: Display saved interactions
- **Features**:
  - Card-based display
  - Delete functionality
  - Empty state
  - Interaction summary

---

## State Management

### Redux Store Structure

```typescript
store {
  form: FormSlice {
    currentInteraction: InteractionFormData,
    savedInteractions: InteractionFormData[],
    isSubmitting: boolean
  },
  chat: ChatSlice {
    messages: ChatMessage[],
    isTyping: boolean,
    conversationStarted: boolean
  }
}
```

### Form Slice

```typescript
// formSlice.ts
Actions:
  - updateField(field, value)        // Update single field
  - updateMultipleFields(data)       // Batch update (used by AI)
  - resetForm()                      // Clear all fields
  - saveInteraction()                // Save to history
  - setSubmitting(boolean)           // Loading state
  - deleteInteraction(index)         // Remove from history

State Shape:
  currentInteraction: {
    hcpName: string
    hospitalName: string
    interactionType: string
    date: string
    time: string
    notes: string
    productsDiscussed: string[]
    followUpRequired: boolean
    followUpDate: string
    followUpNotes: string
    meetingDuration: string
    interactionOutcome: string
    keyDiscussionPoints: string
  }
```

### Chat Slice

```typescript
// chatSlice.ts
Actions:
  - addMessage(message)              // Add to conversation
  - setTyping(boolean)               // Show typing indicator
  - clearChat()                      // Reset conversation
  - startConversation()              // Initialize chat

State Shape:
  messages: [{
    id: string
    role: 'user' | 'assistant'
    content: string
    timestamp: number
    extractedData?: Partial<InteractionFormData>
  }]
```

### State Update Flow

```
User Action (Chat or Form)
        ↓
Action Creator Called
        ↓
Reducer Updates State
        ↓
Store Notified
        ↓
useSelector Hooks Triggered
        ↓
Components Re-render
```

---

## AI Agent Design

### Mock AI Agent (Frontend Implementation)

The AI agent is implemented as a TypeScript class that simulates LangGraph behavior.

### 5 Core Tools

#### Tool 1: HCP Name Extractor
```typescript
extractHCPName(text: string): string | null {
  const patterns = [
    /(?:Dr\.?|Doctor|Prof\.?)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)/i,
    /met\s+(?:with\s+)?([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)/i,
  ];
  // Returns: "Dr. Sharma", "Prof. Kumar", etc.
}
```
**Use Case**: Extracts doctor names from natural language

#### Tool 2: Hospital Name Extractor
```typescript
extractHospitalName(text: string): string | null {
  const patterns = [
    /(?:at|from|in)\s+([A-Z][a-z]+\s+(?:Hospital|Medical|Clinic))/i,
    /(Apollo|Fortis|Max|Manipal|AIIMS)/i,
  ];
  // Returns: "Apollo Hospital", "Fortis Healthcare", etc.
}
```
**Use Case**: Identifies healthcare facilities

#### Tool 3: Interaction Type Classifier
```typescript
extractInteractionType(text: string): string | null {
  const types = {
    'in-person': /(?:in-person|visited|met)/i,
    'virtual': /(?:virtual|zoom|teams)/i,
    'phone': /(?:phone|call)/i,
  };
  // Returns: "in-person", "virtual", "phone", "email"
}
```
**Use Case**: Determines meeting type from context

#### Tool 4: Data Validator
```typescript
validateInteraction(data: InteractionFormData): ValidationResult {
  const required = ['hcpName', 'hospitalName', 'interactionType', 'date'];
  const missing = required.filter(field => !data[field]);
  return { valid: missing.length === 0, missingFields: missing };
}
```
**Use Case**: Ensures completeness before submission

#### Tool 5: Action Suggester
```typescript
suggestNextAction(data: InteractionFormData): string {
  if (data.followUpRequired && !data.followUpDate) {
    return 'Schedule a specific follow-up date';
  }
  if (data.interactionOutcome === 'Needs Follow-up') {
    return 'Create a detailed follow-up plan';
  }
  return 'Interaction logged successfully';
}
```
**Use Case**: Provides intelligent next steps

### Conversation State Machine

```
START
  ↓
[hasHCP?] NO → Ask for HCP name
  ↓ YES
[hasHospital?] NO → Ask for hospital
  ↓ YES
[hasType?] NO → Ask for interaction type
  ↓ YES
[hasProducts?] NO → Ask for products discussed
  ↓ YES
[hasNotes?] NO → Ask for notes/outcome
  ↓ YES
[hasFollowUp?] NO → Ask about follow-up
  ↓ YES
COMPLETE → Allow additional details
```

### Agent Processing Pipeline

```typescript
async processUserMessage(userMessage: string, currentFormData: InteractionFormData)
  : Promise<AgentResponse> {
  
  // Step 1: Extract all possible entities
  const hcpName = this.extractHCPName(userMessage);
  const hospital = this.extractHospitalName(userMessage);
  const type = this.extractInteractionType(userMessage);
  const products = this.extractProducts(userMessage);
  
  // Step 2: Build extracted data object
  let extractedData: Partial<InteractionFormData> = {};
  if (hcpName) extractedData.hcpName = hcpName;
  if (hospital) extractedData.hospitalName = hospital;
  // ... etc
  
  // Step 3: Determine conversation state
  if (!this.conversationState.hasHCP) {
    // Ask for HCP
  } else if (!this.conversationState.hasHospital) {
    // Ask for hospital
  }
  // ... etc
  
  // Step 4: Generate response
  return {
    message: responseMessage + nextQuestion,
    extractedData,
    nextQuestion
  };
}
```

---

## Data Flow

### Complete User Interaction Flow

```
┌─────────────────────────────────────────────────────────┐
│ Step 1: User types in ChatView                         │
│ "I met Dr. Sharma from Apollo"                         │
└─────────────────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────────────────┐
│ Step 2: Add user message to Redux chat state           │
│ dispatch(addMessage({ role: 'user', content: ... }))   │
└─────────────────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────────────────┐
│ Step 3: Call AI Agent                                  │
│ const response = await aiAgent.processUserMessage(...) │
└─────────────────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────────────────┐
│ Step 4: AI extracts entities                           │
│ { hcpName: "Dr. Sharma", hospitalName: "Apollo" }      │
└─────────────────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────────────────┐
│ Step 5: Update form state in Redux                     │
│ dispatch(updateMultipleFields(extractedData))          │
└─────────────────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────────────────┐
│ Step 6: Components re-render                           │
│ - FormView shows new data                              │
│ - Live Status Panel updates progress                   │
│ - ChatView displays assistant response                 │
└─────────────────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────────────────┐
│ Step 7: Add AI response to chat                        │
│ dispatch(addMessage({ role: 'assistant', ... }))       │
└─────────────────────────────────────────────────────────┘
```

### Form Submission Flow

```
User clicks "Save Interaction" in FormView
                ↓
handleSubmit() validation
                ↓
        [Valid?] ────NO──→ Show error toast
            │ YES
            ↓
dispatch(saveInteraction())
            ↓
Current interaction saved to savedInteractions[]
            ↓
dispatch(clearChat()) + dispatch(resetForm())
            ↓
aiAgent.resetConversation()
            ↓
Show success toast
            ↓
Ready for next interaction
```

---

## Backend Architecture (Production)

### When Connected to Supabase

```
Frontend (React)
      ↓
Supabase Edge Functions (Deno/TypeScript)
      ↓
┌────────────────────────────────────┐
│  LangGraph Agent Orchestration     │
│  ┌──────────────────────────────┐  │
│  │  Tool 1: Log Interaction     │  │
│  │  - Calls Groq API            │  │
│  │  - Extracts entities         │  │
│  │  - Stores in PostgreSQL      │  │
│  └──────────────────────────────┘  │
│  ┌──────────────────────────────┐  │
│  │  Tool 2: Edit Interaction    │  │
│  │  - Updates database          │  │
│  └──────────────────────────────┘  │
│  ┌──────────────────────────────┐  │
│  │  Tool 3: Fetch HCP Data      │  │
│  │  - Queries PostgreSQL        │  │
│  │  - Returns HCP history       │  │
│  └──────────────────────────────┘  │
│  ┌──────────────────────────────┐  │
│  │  Tool 4: Suggest Next Action │  │
│  │  - AI-powered analysis       │  │
│  └──────────────────────────────┘  │
│  ┌──────────────────────────────┐  │
│  │  Tool 5: Validate Data       │  │
│  │  - Business logic checks     │  │
│  └──────────────────────────────┘  │
└────────────────────────────────────┘
      ↓
┌────────────────────────────────────┐
│  Groq API (LLM Inference)          │
│  - Model: gemma2-9b-it             │
│  - Entity extraction               │
│  - Response generation             │
└────────────────────────────────────┘
      ↓
┌────────────────────────────────────┐
│  PostgreSQL Database               │
│  ┌──────────────────────────────┐  │
│  │  Table: interactions         │  │
│  │  - id (UUID)                 │  │
│  │  - user_id (FK)              │  │
│  │  - hcp_name (TEXT)           │  │
│  │  - hospital_name (TEXT)      │  │
│  │  - interaction_type (TEXT)   │  │
│  │  - date (DATE)               │  │
│  │  - notes (TEXT)              │  │
│  │  - products (JSONB)          │  │
│  │  - created_at (TIMESTAMP)    │  │
│  └──────────────────────────────┘  │
└────────────────────────────────────┘
```

### Database Schema (Production)

```sql
CREATE TABLE interactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id),
  hcp_name TEXT NOT NULL,
  hospital_name TEXT NOT NULL,
  interaction_type TEXT NOT NULL,
  date DATE NOT NULL,
  time TIME,
  notes TEXT,
  products_discussed JSONB DEFAULT '[]',
  follow_up_required BOOLEAN DEFAULT false,
  follow_up_date DATE,
  follow_up_notes TEXT,
  meeting_duration TEXT,
  interaction_outcome TEXT,
  key_discussion_points TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_interactions_user_id ON interactions(user_id);
CREATE INDEX idx_interactions_date ON interactions(date DESC);
CREATE INDEX idx_interactions_hcp ON interactions(hcp_name);

CREATE TABLE chat_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id),
  interaction_id UUID REFERENCES interactions(id),
  role TEXT NOT NULL CHECK (role IN ('user', 'assistant')),
  content TEXT NOT NULL,
  extracted_data JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

### API Endpoints (Supabase Edge Functions)

```typescript
// functions/api/interaction/index.ts
export default async function handler(req: Request) {
  const { method } = req;
  
  switch (method) {
    case 'POST':
      return createInteraction(req);
    case 'GET':
      return getInteractions(req);
    case 'PUT':
      return updateInteraction(req);
    case 'DELETE':
      return deleteInteraction(req);
  }
}

// functions/api/chat/index.ts
export default async function handler(req: Request) {
  const { message, context } = await req.json();
  
  // Call LangGraph agent
  const agent = new LangGraphAgent(process.env.GROQ_API_KEY);
  const response = await agent.process(message, context);
  
  return new Response(JSON.stringify(response));
}
```

---

## Security Architecture

### Authentication Flow

```
User Login
    ↓
Supabase Auth (JWT)
    ↓
Token stored in browser
    ↓
All API calls include token
    ↓
Edge Functions validate token
    ↓
Row-level security enforced
```

### Data Protection

1. **Encryption**
   - TLS 1.3 for data in transit
   - AES-256 for data at rest
   - Encrypted database fields for sensitive data

2. **Access Control**
   ```sql
   -- Row-level security policy
   CREATE POLICY "Users can only see their own interactions"
     ON interactions FOR SELECT
     USING (auth.uid() = user_id);
   ```

3. **API Key Management**
   - Groq API key stored in Supabase secrets
   - Never exposed to frontend
   - Rotated regularly

4. **Input Sanitization**
   ```typescript
   function sanitizeInput(input: string): string {
     return input
       .replace(/</g, '&lt;')
       .replace(/>/g, '&gt;')
       .trim()
       .slice(0, 5000); // Max length
   }
   ```

---

## Performance Optimization

### Frontend
- **Code Splitting**: Lazy load components
- **Memoization**: React.memo for expensive components
- **Debouncing**: AI agent calls debounced 300ms
- **Virtual Scrolling**: For long chat histories

### Backend
- **Connection Pooling**: PostgreSQL connections
- **Caching**: Redis for frequent queries
- **Rate Limiting**: 100 requests/minute per user
- **CDN**: Static assets on Cloudflare

---

## Monitoring & Observability

### Metrics to Track

1. **User Engagement**
   - Chat vs Form usage ratio
   - Average fields filled via chat
   - Conversation length

2. **AI Performance**
   - Entity extraction accuracy
   - Conversation completion rate
   - Time to complete interaction

3. **System Health**
   - API response times
   - Error rates
   - Database query performance

### Logging

```typescript
logger.info('Interaction logged', {
  userId: user.id,
  method: 'chat',
  fieldsExtracted: Object.keys(extractedData),
  duration: Date.now() - startTime
});
```

---

## Scalability Considerations

### Horizontal Scaling
- Supabase Edge Functions auto-scale
- PostgreSQL read replicas
- Load balancing across regions

### Vertical Scaling
- Upgrade database instance
- Increase connection pool size
- More powerful Edge Function instances

---

## Deployment Architecture

```
GitHub Repository
      ↓
CI/CD Pipeline (GitHub Actions)
      ↓
┌─────────────────────────────┐
│  Build Frontend             │
│  - pnpm build               │
│  - Optimize assets          │
└─────────────────────────────┘
      ↓
┌─────────────────────────────┐
│  Deploy to Figma Make       │
│  or Vercel/Netlify          │
└─────────────────────────────┘
      ↓
┌─────────────────────────────┐
│  Deploy Edge Functions      │
│  - supabase functions deploy│
└─────────────────────────────┘
      ↓
┌─────────────────────────────┐
│  Run Migrations             │
│  - supabase db push         │
└─────────────────────────────┘
      ↓
Production Live
```

---

This architecture is designed for scalability, security, and maintainability while providing an excellent user experience through AI-powered interactions.
